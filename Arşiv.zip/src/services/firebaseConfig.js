// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB6OUb-Vka4ljCcqTNEsacd2jIuj3ivQjI",
  authDomain: "filmflare-93b96.firebaseapp.com",
  projectId: "filmflare-93b96",
  storageBucket: "filmflare-93b96.appspot.com",
  messagingSenderId: "928640420604",
  appId: "1:928640420604:web:93d6b40fef454002bda579",
  measurementId: "G-E6HH3L0MQF"
};

console.log('TEST')
// Initialize Firebase
const firebaseInit = initializeApp(firebaseConfig);
const auth = getAuth(firebaseInit);

export default firebaseInit
export { auth }